class Property {
  String address;
  double price;
  String description;
  int bedrooms;
  int bathrooms;
  String imageUrl; // For property image path (optional)


  Property({
    required this.address,
    required this.price,
    required this.description,
    required this.bedrooms,
    required this.bathrooms,
    required this.imageUrl,
  });

  // Method to convert Property object to CSV format (comma-separated string)
  String toCsv() {
    return '$address,$price,$description,$bedrooms,$bathrooms,$imageUrl';
  }

  // Static method to create a Property object from a CSV string
  static Property fromCsv(String csv) {
    List<String> values = csv.split(',');

    return Property(
      address: values[0],
      price: double.parse(values[1]),  // Convert price from string to double
      description: values[2],
      bedrooms: int.parse(values[3]),  // Convert bedrooms from string to int
      bathrooms: int.parse(values[4]), // Convert bathrooms from string to int
      imageUrl: values[5],
    );
  }
}
