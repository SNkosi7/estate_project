import 'dart:math';
import 'dart:io';
import 'package:flutter/material.dart';
import 'property.dart';
import 'package:estate/file_manager.dart';
import 'package:estate/AddEditPropertyScreen.dart';

class AllPropertiesScreen extends StatefulWidget {
  final List<Property> allProperties;

  const AllPropertiesScreen({super.key, required this.allProperties});

  @override
  _AllPropertiesScreenState createState() => _AllPropertiesScreenState();
}

class _AllPropertiesScreenState extends State<AllPropertiesScreen> {
  void editAt(int index, Property updatedProperty) {
    setState(() {
      widget.allProperties[index] = updatedProperty; // Update the property
    });
    FileManager.writeProperties(widget.allProperties); // Save the updated properties
  }

  void _deleteProperty(int index) {
    setState(() {
      widget.allProperties.removeAt(index); // Remove property at index
    });
    FileManager.writeProperties(widget.allProperties); // Save updated properties
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 15, 32, 39),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: const Color.fromARGB(255, 255, 255, 255)),
          onPressed: () {
            Navigator.pop(context); // Go back to the Home screen
          },
        ),
        title: Text('All Properties', style: TextStyle(color: const Color.fromARGB(255, 255, 255, 255))),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0F2027),
              Color(0xFF203A43),
              Color(0xFF2C5364),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: widget.allProperties.isEmpty
              ? Center(
                  child: Text(
                    'No properties available',
                    style: TextStyle(color: Colors.white, fontSize: 18),
                  ),
                )
              : GridView.builder(
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    childAspectRatio: 0.65,
                    crossAxisSpacing: 10,
                    mainAxisSpacing: 10,
                  ),
                  itemCount: widget.allProperties.length,
                  itemBuilder: (context, index) {
                    return PropertyCard(
                      property: widget.allProperties[index],
                      onEdit: (updatedProperty) => editAt(index, updatedProperty),
                      onDelete: () => _confirmDelete(context, index),
                    );
                  },
                ),
        ),
      ),
    );
  }

  void _confirmDelete(BuildContext context, int index) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Delete Property'),
          content: Text('Are you sure you want to delete this property?'),
          actions: [
            TextButton(
              onPressed: () {
                _deleteProperty(index);
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('Yes'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close the dialog
              },
              child: Text('No'),
            ),
          ],
        );
      },
    );
  }
}

class PropertyCard extends StatelessWidget {
  final Property property;
  final Function(Property) onEdit;
  final VoidCallback onDelete;

   PropertyCard({super.key, required this.property, required this.onEdit, required this.onDelete});

  // List of available asset images
  final List<String> _images = [
    'assets/house1.jpg',
    'assets/house2.jpg',
    'assets/house3.jpg',
    'assets/house4.jpg',
    'assets/house5.jpg',
    'assets/house6.jpg',
  ];

  // Function to pick a random image from the list
  String _getRandomImage() {
    final random = Random();
    return _images[random.nextInt(_images.length)];
  }

  @override
  Widget build(BuildContext context) {
    // Pick a random image for each property card
    final randomImage = _getRandomImage();

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 200,
            decoration: BoxDecoration(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
              image: DecorationImage(
                image: property.imageUrl.isNotEmpty
                    ? FileImage(File(property.imageUrl))
                    : AssetImage(randomImage) as ImageProvider, // Use random image here
                fit: BoxFit.cover,
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  property.address,
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                ),
                SizedBox(height: 5),
                Text(
                  'R${property.price}',
                  style: TextStyle(color: Colors.redAccent, fontSize: 16),
                ),
                SizedBox(height: 5),
                Text(
                  'Bedrooms: ${property.bedrooms} Bathrooms: ${property.bathrooms}',
                  style: TextStyle(fontSize: 14, color: Colors.grey),
                ),
                SizedBox(height: 5),
                Text(
                  property.description,
                  style: TextStyle(fontSize: 14, color: Colors.grey),
                ),
                SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton.icon(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => AddEditPropertyScreen(property: property, onSave: onEdit),
                          ),
                        );
                      },
                      icon: Icon(Icons.edit),
                      label: Text('Edit'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue,
                      ),
                    ),
                    ElevatedButton.icon(
                      onPressed: onDelete,
                      icon: Icon(Icons.delete),
                      label: Text('Delete'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
