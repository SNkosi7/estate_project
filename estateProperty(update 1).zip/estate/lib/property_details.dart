import 'dart:io';
import 'package:flutter/material.dart';
import 'dart:math';
import 'property.dart'; // Import the Property model

class PropertyDetailScreen extends StatelessWidget {
  final Property property;

  // List of available asset images
  final List<String> _images = [
    'assets/house1.jpg',
    'assets/house2.jpg',
    'assets/house3.jpg',
    'assets/house4.jpg',
    'assets/house5.jpg',
    'assets/house6.jpg',
  ];

  PropertyDetailScreen({super.key, required this.property});

  // Function to pick a random image from the list
  String _getRandomImage() {
    final random = Random();
    return _images[random.nextInt(_images.length)];
  }

  @override
  Widget build(BuildContext context) {
    // Get a random image for the property
    final randomImage = _getRandomImage();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 15, 32, 39),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text('Property Details', style: TextStyle(color: Colors.white)),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Property Image
            Container(
              height: 250.0,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                image: DecorationImage(
                  image: property.imageUrl.isNotEmpty
                      ? FileImage(File(property.imageUrl))
                      : AssetImage(randomImage) as ImageProvider, // Display random image
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Property Title
                  Text(
                    property.address,
                    style: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10.0),

                  // Location
                  Row(
                    children: [
                      Icon(Icons.location_on, color: Colors.grey),
                      SizedBox(width: 5.0),
                      Text(
                        property.address,
                        style: TextStyle(color: Colors.grey),
                      ),
                    ],
                  ),
                  SizedBox(height: 20.0),

                  // Property Features like price, bedrooms, etc.
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildFeatureIcon(Icons.monetization_on, 'Price', '\$${property.price}'), // Displaying the price
                      _buildFeatureIcon(Icons.king_bed, 'Bedrooms', property.bedrooms.toString()),
                    ],
                  ),
                  SizedBox(height: 10.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _buildFeatureIcon(Icons.bathtub, 'Bathrooms', property.bathrooms.toString()),
                      _buildFeatureIcon(Icons.monetization_on, 'Down payment', '20%'),
                      _buildFeatureIcon(Icons.date_range, 'Handover', '2024'),
                    ],
                  ),
                  SizedBox(height: 20.0),

                  // DLD Waiver and Contact Button
                  Card(
                    margin: EdgeInsets.symmetric(vertical: 10.0),
                    child: ListTile(
                      tileColor: Colors.black87,
                      title: Center(
                        child: Text(
                          'WAIVER : 100%',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                        ),
                      ),
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      // Handle contact action
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.redAccent,
                      padding: EdgeInsets.symmetric(vertical: 15),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Center(
                      child: Text(
                        'Get in touch : 051 235 3348',
                        style: TextStyle(fontSize: 16, color: Colors.white),
                      ),
                    ),
                  ),

                  // Property Description
                  SizedBox(height: 20.0),
                  Text(
                    "Property Details: ",
                    semanticsLabel: property.description, // Displaying the property description
                    style: TextStyle(fontSize: 16.0),
                  ),

                  SizedBox(height: 20.0),
                  // Key Attractions Section
                  _buildKeyAttractions(),
                  SizedBox(height: 20.0),

                  // Features & Amenities Section
                  _buildFeatureList(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // Widget for feature icons like bedrooms, size, type, etc.
  Widget _buildFeatureIcon(IconData icon, String title, String value) {
    return Column(
      children: [
        Icon(icon, color: Colors.black87),
        SizedBox(height: 5.0),
        Text(title, style: TextStyle(color: Colors.black87)),
        SizedBox(height: 5.0),
        Text(value, style: TextStyle(fontWeight: FontWeight.bold)),
      ],
    );
  }

  // Key Attractions section
  Widget _buildKeyAttractions() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Key Attractions',
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10.0),
            Text(
              'Luxury filled premium edition villas. Top-notch amenities and facilities. Walking Distance from shopping malls, restaurants, and entertainment hubs.',
              style: TextStyle(fontSize: 16.0),
            ),
          ],
        ),
      ),
    );
  }

  // Features and Amenities section
  Widget _buildFeatureList() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Features & Amenities',
              style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10.0),
            Text(
              '- Backyard air-conditioned gym.\n- BBQ counter.\n- Swimming pool with premium wooden deck.\n- Pergola and garage enclosures.',
              style: TextStyle(fontSize: 16.0),
            ),
          ],
        ),
      ),
    );
  }
}
