import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'property.dart';


class FileManager {
  static Future<String> getFilePath() async {
    final directory = await getApplicationDocumentsDirectory();
    return '${directory.path}/properties.txt';
  }

  static Future<File> getFile() async {
    final path = await getFilePath();
    return File(path);
  }

  static Future<void> writeProperties(List<Property> properties) async {
    try {
      final file = await getFile();
      String content = properties.map((p) => p.toCsv()).join('\n');
      await file.writeAsString(content);
    } catch (e) {
      print('Error writing to file: $e');
    }
  }

  static Future<List<Property>> readProperties() async {
    try {
      final file = await getFile();
      if (await file.exists()) {
        String content = await file.readAsString();
        List<Property> properties = content
            .split('\n')
            .map((line) => Property.fromCsv(line))
            .toList();
        return properties;
      } else {
        return [];
      }
    } catch (e) {
      print('Error reading file: $e');
      return [];
    }
  }
}
