import 'dart:math';
import 'dart:io';
import 'package:flutter/material.dart';
import 'property.dart';
import 'add_property.dart';
import 'all_properties.dart';
import 'property_details.dart';
import 'sign_in_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Property> featuredProperties = [];

  // This method will be called when a new property is added
  void addProperty(Property newProperty) {
    setState(() {
      featuredProperties.add(newProperty);

    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 15, 32, 39),
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.menu, color: Colors.white),
          onPressed: () => Scaffold.of(context).openDrawer(),
        ),
        title: Text('Properties', style: TextStyle(color: Colors.white)),
        actions: [
          IconButton(
            icon: Icon(Icons.star_border, color: Colors.white),
            onPressed: () {},
          ),
          IconButton(
            icon: Icon(Icons.notifications_none, color: Colors.white),
            onPressed: () {},
          ),
        ],
      ),
      drawer: Drawer(
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                Color(0xFF0F2027),
                Color(0xFF203A43),
                Color(0xFF2C5364),
              ],
            ),
          ),
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: const BoxDecoration(color: Colors.black),
                child: Center(
                  child: Text('Menu', style: TextStyle(color: Colors.white, fontSize: 24)),
                ),
              ),
              _createDrawerItem(Icons.home, 'Home', () => Navigator.pop(context)),
              _createDrawerItem(Icons.apartment, 'Properties', () => Navigator.pop(context)),
              _createDrawerItem(Icons.info, 'About', () => Navigator.pop(context)),
              _createDrawerItem(Icons.contact_mail, 'Contact Us', () => Navigator.pop(context)),
              _createDrawerItem(Icons.exit_to_app, 'Exit', () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => SignInScreen()),
                );
              }),
              const Divider(color: Colors.white),
            ],
          ),
        ),
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFF0F2027),
              Color(0xFF203A43),
              Color(0xFF2C5364),
            ],
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              _buildSearchBar(),
              const SizedBox(height: 20),
              _buildFeaturedPropertiesHeader(context),
              const SizedBox(height: 10),
              _buildFeaturedPropertiesList(),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final newProperty = await Navigator.push<Property>(
            context,
            MaterialPageRoute(builder: (context) => AddPropertyScreen()),
          );
          if (newProperty != null) {
            addProperty(newProperty);
          }
        },
        backgroundColor: Colors.redAccent,
        child: Icon(Icons.add),
      ),
    );
  }

  Widget _createDrawerItem(IconData icon, String text, Function() onTap) {
    return ListTile(
      leading: Icon(icon, color: Colors.white),
      title: Text(text, style: TextStyle(color: Colors.white)),
      onTap: onTap,
    );
  }

  Widget _buildSearchBar() {
    return Container(
      height: 50,
      padding: EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.grey[200],
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        children: [
          Icon(Icons.search, color: Colors.grey),
          const SizedBox(width: 10),
          Expanded(
            child: TextField(
              decoration: InputDecoration(
                hintText: "Search properties",
                border: InputBorder.none,
              ),
            ),
          ),
          Icon(Icons.tune, color: Colors.grey),
        ],
      ),
    );
  }

  Widget _buildFeaturedPropertiesHeader(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text('Featured properties', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        TextButton(
          onPressed: () async {
            final newProperty = await Navigator.push<Property>(
              context,
              MaterialPageRoute(builder: (context) => AllPropertiesScreen(allProperties: featuredProperties)),
            );
            if (newProperty != null) {
              addProperty(newProperty);
             
            }
          },
          child: Text('View All', style: TextStyle(color: Colors.redAccent)),
        ),
      ],
    );
  }

  Widget _buildFeaturedPropertiesList() {
    return SizedBox(
      height: 400,
      child: featuredProperties.isEmpty
          ? Center(child: Text('No featured properties yet', style: TextStyle(color: Colors.white)))
          : ListView.builder(
              itemCount: featuredProperties.length,
              itemBuilder: (context, index) {
                return PropertyCard(
                  property: featuredProperties[index],
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PropertyDetailScreen(property: featuredProperties[index]),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}

class PropertyCard extends StatelessWidget {
  final Property property;
  final VoidCallback onTap;

  // List of available asset images
  final List<String> _images = [
     'assets/house1.jpg',
    'assets/house2.jpg',
    'assets/house3.jpg',
    'assets/house4.jpg',
    'assets/house5.jpg',
    'assets/house6.jpg',
  ];

  PropertyCard({super.key, required this.property, required this.onTap});

  // Function to pick a random image from the list
  String _getRandomImage() {
    final random = Random();
    return _images[random.nextInt(_images.length)];
  }

  @override
  Widget build(BuildContext context) {
    // Pick a random image for each property card
    final randomImage = _getRandomImage();

    return GestureDetector(
      onTap: onTap,
      child: Card(
        margin: const EdgeInsets.symmetric(vertical: 10),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              
              height: 160, // Adjusted height for better fitting
            width: double.infinity, // Ensures the image covers the width of the card
              decoration: BoxDecoration(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
                image: DecorationImage(
                  image: property.imageUrl.isNotEmpty
                      ? FileImage(File(property.imageUrl))
                      : AssetImage(randomImage) as ImageProvider, // Use random image here
                      
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(property.address, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
                  SizedBox(height: 5),
                  Text('R${property.price}', style: TextStyle(color: Colors.redAccent, fontSize: 16)),
                  SizedBox(height: 5),
                  Text('Bedrooms: ${property.bedrooms} Bathrooms: ${property.bathrooms}', style: TextStyle(fontSize: 14, color: Colors.grey)),
                  SizedBox(height: 5),
                  Text(property.description, style: TextStyle(fontSize: 14, color: Colors.grey)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
