package com.example.estate

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
